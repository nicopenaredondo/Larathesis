Corgi: A Bootstrap Theme with a Very Small Footprint
=========

See the demo: [http://www.3solarmasses.com/corgi-bootstrap/](http://www.3solarmasses.com/corgi-bootstrap/)

### Installation: 

Just download the [zip](https://github.com/damian-sowers/corgi-bootstrap/zipball/master) and include corgi.css after bootstrap.css.

![corgi](https://github.com/damian-sowers/corgi-bootstrap/raw/master/img/corgi.png)

### License:

MIT
